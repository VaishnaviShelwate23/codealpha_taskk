let currentIndex = 0;

const images = document.querySelectorAll(".gallery img");
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightbox-img");

function openLightbox(index){
currentIndex = index;
lightbox.style.display = "flex";
showImage();
}

function closeLightbox(){
lightbox.style.display = "none";
}

function showImage(){
lightboxImg.src = images[currentIndex].src;
}

function changeSlide(step){
currentIndex += step;

if(currentIndex < 0){
currentIndex = images.length - 1;
}

if(currentIndex >= images.length){
currentIndex = 0;
}

showImage();
}

/* Filter Categories */

function filterSelection(category){

let items = document.getElementsByClassName("image");

for(let i=0;i<items.length;i++){

if(category === "all"){
items[i].style.display = "block";
}
else if(items[i].classList.contains(category)){
items[i].style.display = "block";
}
else{
items[i].style.display = "none";
}

}

}